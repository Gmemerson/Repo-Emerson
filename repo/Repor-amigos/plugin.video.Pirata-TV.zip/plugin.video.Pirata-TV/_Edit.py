import xbmcaddon

MainBase = 'http://pastebin.com/raw/ZNbK2SD4'
addon = xbmcaddon.Addon('plugin.video.Pirata-TV')